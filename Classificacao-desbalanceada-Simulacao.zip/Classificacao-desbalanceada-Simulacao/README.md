# Classificacao-desbalanceada

Este reposítorio contém os códigos de analise do efeito de desbalanceamento em modelos de classificação.

  - **Base1**: Notebook original associado a base1

  - **Base2**: Notebook original associado a base2

  - **Base3**: Notebook original associado a base3

  - **Case1**: Notebook do estudo associado a case1

  - **Case2**: Notebook do estudo associado a case2

  - **Case3**: Notebook do estudo associado a case3 
