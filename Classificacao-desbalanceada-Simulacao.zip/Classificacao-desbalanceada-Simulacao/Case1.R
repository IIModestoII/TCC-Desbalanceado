## INTALANDO PACOTES

# install.packages(c("tidyverse", "MASS", "caTools", "caret", "ggplot2", "UBL", 
#                    "smotefamily", "boot", "ROCR", "pROC", "gridExtra", "DMwR2", 
#                    "e1071", "mltools", "tictoc"))
# install.packages(c("randomForest", "xgboost", "glmnet"))


## Carregar bibliotecas necessárias
library(tidyverse)
library(caret)
library(glmnet)
library(randomForest)
library(xgboost)
library(pROC)
library(ROCR)
library(tictoc)


## Função para gerar dados desbalanceados com mais features categóricas
criar_dados <- function(n_observacoes = 1000, proporcao_minoria = 0.005) {
  # Calcular o número de observações por classe
  n_classe_A <- round(n_observacoes * proporcao_minoria)
  n_classe_B <- n_observacoes - n_classe_A
  
  # Garantir que ambas as classes tenham pelo menos uma observação
  if (n_classe_A <= 0 | n_classe_B <= 0) {
    stop("Erro: Número de observações insuficiente para criar ambas as classes.")
  }
  
  # Criar o dataframe com variáveis categóricas
  dados <- data.frame(
    Classe = factor(c(rep("A", n_classe_A), rep("B", n_classe_B))),
    Feature1 = sample(c("X", "Y", "Z"), n_observacoes, replace = TRUE),
    Feature2 = sample(c("A", "B", "C", "D"), n_observacoes, replace = TRUE),
    Feature3 = sample(c("Low", "Medium", "High"), n_observacoes, replace = TRUE),
    Feature4 = sample(c("Yes", "No"), n_observacoes, replace = TRUE),
    Feature5 = sample(c("Red", "Blue", "Green", "Yellow"), n_observacoes, replace = TRUE)
  )
  
  # Embaralhar os dados
  dados <- dados[sample(nrow(dados)), ]
  return(dados)
}


## Cenários de desbalanceamento
cenarios <- list(
  "0.5%" = 0.005,
  "1%" = 0.01,
  "3.5%" = 0.035
)

## Loop para criar dados, dividir em treino/validação/teste, aplicar os modelos e realizar tuning de hiperparâmetros
resultados <- list()


for (cenario in names(cenarios)) {
  cat("\nRodando cenário de desbalanceamento:", cenario, "\n")
  dados <- criar_dados(1000, cenarios[[cenario]])
  
  # Dividir em treino (70%), validação (15%) e teste (15%)
  set.seed(42)
  indices <- createDataPartition(dados$Classe, p = 0.7, list = FALSE)
  treino <- dados[indices, ]
  dados_restante <- dados[-indices, ]
  
  indices_val <- createDataPartition(dados_restante$Classe, p = 0.5, list = FALSE)
  validacao <- dados_restante[indices_val, ]
  teste <- dados_restante[-indices_val, ]
  
  # Oversampling da classe minoritária no conjunto de treino
  treino_balanceado <- treino
  
  ## Regressão Logística LASSO
  cat("Treinando modelo: Regressão Logística LASSO\n")
  tic()
  x_treino <- model.matrix(Classe ~ . - 1, data = treino_balanceado)
  y_treino <- treino_balanceado$Classe
  
  lasso_model <- cv.glmnet(x_treino, y_treino, family = "binomial", alpha = 1)
  toc()
  
  x_validacao <- model.matrix(Classe ~ . - 1, data = validacao, xlev = attr(x_treino, "dimnames")[[2]])
  x_teste <- model.matrix(Classe ~ . - 1, data = teste, xlev = attr(x_treino, "dimnames")[[2]])
  
  previsoes_lasso_val <- predict(lasso_model, newx = x_validacao, type = "response")
  previsoes_lasso_teste <- predict(lasso_model, newx = x_teste, type = "response")
  
  ## Random Forest
  cat("Treinando modelo: Random Forest\n")
  tic()
  tune_grid_rf <- expand.grid(mtry = c(2, 4, 6))
  rf_model <- train(Classe ~ ., data = treino_balanceado, method = "rf", tuneGrid = tune_grid_rf, trControl = trainControl(method = "cv", number = 5))
  toc()
  previsoes_rf_val <- predict(rf_model, newdata = validacao, type = "prob")[, 2]
  previsoes_rf_teste <- predict(rf_model, newdata = teste, type = "prob")[, 2]
  
  ## XGBoost
  cat("Treinando modelo: XGBoost\n")
  tic()
  tune_grid_xgb <- expand.grid(
    nrounds = c(50, 100, 150),
    max_depth = c(3, 6, 9),
    eta = c(0.01, 0.1, 0.3),
    gamma = c(0, 1),
    colsample_bytree = c(0.8, 1),
    min_child_weight = c(1, 5),
    subsample = c(0.8, 1)
  )
  
  xgb_model <- train(
    Classe ~ ., data = treino_balanceado, method = "xgbTree",
    tuneGrid = tune_grid_xgb, trControl = trainControl(method = "cv", number = 5)
  )
  toc()
  previsoes_xgb_val <- predict(xgb_model, newdata = validacao, type = "prob")[, 2]
  previsoes_xgb_teste <- predict(xgb_model, newdata = teste, type = "prob")[, 2]
  
  ## Avaliação dos modelos no conjunto de validação e teste
  modelos <- list(
    "LASSO" = list(previsoes_val = previsoes_lasso_val, previsoes_teste = previsoes_lasso_teste),
    "Random Forest" = list(previsoes_val = previsoes_rf_val, previsoes_teste = previsoes_rf_teste),
    "XGBoost" = list(previsoes_val = previsoes_xgb_val, previsoes_teste = previsoes_xgb_teste)
  )
  
  for (nome_modelo in names(modelos)) {
    previsoes_val <- factor(ifelse(modelos[[nome_modelo]]$previsoes_val > 0.5, "A", "B"), levels = levels(validacao$Classe))
    previsoes_teste <- factor(ifelse(modelos[[nome_modelo]]$previsoes_teste > 0.5, "A", "B"), levels = levels(teste$Classe))
    
    # Avaliação no conjunto de validação
    if (length(previsoes_val) == length(validacao$Classe)) {
      matriz_confusao_val <- confusionMatrix(previsoes_val, validacao$Classe, positive = "A")
    } else {
      stop("Erro: O número de previsões não corresponde ao número de observações no conjunto de validação.")
    }
    
    # Avaliação no conjunto de teste
    if (length(previsoes_teste) == length(teste$Classe)) {
      matriz_confusao_teste <- confusionMatrix(previsoes_teste, teste$Classe, positive = "A")
    } else {
      stop("Erro: O número de previsões não corresponde ao número de observações no conjunto de teste.")
    }
    
    # Cálculo da AUC apenas se houver ambas as classes
    if (length(unique(validacao$Classe)) == 2) {
      auc_val <- roc(validacao$Classe, modelos[[nome_modelo]]$previsoes_val)$auc
    } else {
      auc_val <- NA
      cat("Aviso: Não há ambas as classes no conjunto de validação. AUC não calculado.\n")
    }
    
    if (length(unique(teste$Classe)) == 2) {
      auc_teste <- roc(teste$Classe, modelos[[nome_modelo]]$previsoes_teste)$auc
    } else {
      auc_teste <- NA
      cat("Aviso: Não há ambas as classes no conjunto de teste. AUC não calculado.\n")
    }
    
    # Armazenar resultados
    resultados[[paste(cenario, nome_modelo, "Validação", sep = " - ")]] <- list(
      Matriz_Confusao = matriz_confusao_val,
      AUC = auc_val,
      Métricas = matriz_confusao_val$byClass
    )
    
    resultados[[paste(cenario, nome_modelo, "Teste", sep = " - ")]] <- list(
      Matriz_Confusao = matriz_confusao_teste,
      AUC = auc_teste,
      Métricas = matriz_confusao_teste$byClass
    )
  }
}


## Exibir resultados
for (resultado in names(resultados)) {
  cat("\n---", resultado, "---\n")
  print(resultados[[resultado]]$Matriz_Confusao)
  cat("AUC:", resultados[[resultado]]$AUC, "\n")
  print(resultados[[resultado]]$Métricas)
}

## Comparação gráfica das performances
library(ggplot2)
métricas <- data.frame()

for (resultado in names(resultados)) {
  métricas <- rbind(métricas, data.frame(
    Cenário = resultado,
    AUC = resultados[[resultado]]$AUC,
    Sensibilidade = resultados[[resultado]]$Métricas["Sensitivity"],
    Especificidade = resultados[[resultado]]$Métricas["Specificity"]
  ))
}

## Gráfico de comparação de AUC
ggplot(métricas, aes(x = reorder(Cenário, AUC), y = AUC, fill = Cenário)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  labs(title = "Comparação de AUC entre Modelos", x = "Cenário e Modelo", y = "AUC") +
  theme_minimal()

## Gráfico de comparação de Sensibilidade e Especificidade
ggplot(métricas, aes(x = reorder(Cenário, Sensibilidade), y = Sensibilidade, fill = Cenário)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  labs(title = "Comparação de Sensibilidade entre Modelos", x = "Cenário e Modelo", y = "Sensibilidade") +
  theme_minimal()

ggplot(métricas, aes(x = reorder(Cenário, Especificidade), y = Especificidade, fill = Cenário)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  labs(title = "Comparação de Especificidade entre Modelos", x = "Cenário e Modelo", y = "Especificidade") +
  theme_minimal()
