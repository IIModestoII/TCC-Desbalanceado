## INTALANDO PACOTES

# install.packages(c("tidyverse", "MASS", "caTools", "caret", "ggplot2", "UBL", 
#                    "smotefamily", "boot", "ROCR", "pROC", "gridExtra", "DMwR2", 
#                    "e1071", "mltools", "tictoc"))
# install.packages(c("randomForest", "xgboost", "glmnet"))

## Carregar bibliotecas necessárias
library(tidyverse)
library(caret)
library(glmnet)
library(randomForest)
library(xgboost)
library(pROC)
library(ROCR)
library(tictoc)

## Função para gerar dados desbalanceados
# criar_dados <- function(n_observacoes = 1000, proporcao_minoria = 0.005) {
#   n_classe_A <- round(n_observacoes * proporcao_minoria)
#   n_classe_B <- n_observacoes - n_classe_A
#   
#   dados <- data.frame(
#     Classe = factor(c(rep("A", n_classe_A), rep("B", n_classe_B))),
#     replicate(200, sample(c("X", "Y", "Z"), n_observacoes, replace = TRUE))
#   )
#   dados <- dados[sample(nrow(dados)), ]  # Embaralhar dados
#   return(dados)
# }


## Função para gerar dados desbalanceados mistos
criar_dados_mistos <- function(n_observacoes = 10000, proporcao_minoria = 0.005) {
  n_classe_A <- round(n_observacoes * proporcao_minoria)
  n_classe_B <- n_observacoes - n_classe_A
  
  dados <- data.frame(
    Classe = factor(c(rep("A", n_classe_A), rep("B", n_classe_B))),
    replicate(100, rnorm(n_observacoes, mean = 50, sd = 10)),  # 100 variáveis contínuas
    replicate(100, sample(c("X", "Y", "Z"), n_observacoes, replace = TRUE))  # 100 variáveis categóricas
  )
  dados <- dados[sample(nrow(dados)), ]  # Embaralhar dados
  return(dados)
}


## Cenários de desbalanceamento
cenarios <- list(
  "0.5%" = 0.005,
  "1%" = 0.01,
  "3.5%" = 0.035
)

## Loop para criar dados, dividir em treino/validação/teste, aplicar os modelos e realizar tuning de hiperparâmetros
resultados <- list()

for (cenario in names(cenarios)) {
  cat("\nRodando cenário de desbalanceamento:", cenario, "\n")
  dados <- criar_dados(1000, cenarios[[cenario]])
  
  # Dividir em treino (70%), validação (15%) e teste (15%)
  set.seed(42)
  indices <- createDataPartition(dados$Classe, p = 0.7, list = FALSE)
  treino <- dados[indices, ]
  dados_restante <- dados[-indices, ]
  
  indices_val <- createDataPartition(dados_restante$Classe, p = 0.5, list = FALSE)
  validacao <- dados_restante[indices_val, ]
  teste <- dados_restante[-indices_val, ]
  
  # Oversampling da classe minoritária no conjunto de treino
  treino_balanceado <- treino %>%
    filter(Classe == "A") %>%
    slice_sample(n = sum(treino$Classe == "B")) %>%
    bind_rows(filter(treino, Classe == "B"))
  
  ## Tuning de hiperparâmetros para Regressão Logística LASSO
  cat("Treinando modelo: Regressão Logística LASSO\n")
  tic()
  x_treino <- model.matrix(Classe ~ . - 1, data = treino_balanceado)
  y_treino <- treino_balanceado$Classe
  
  lasso_model <- cv.glmnet(x_treino, y_treino, family = "binomial", alpha = 1)
  toc()
  
  x_validacao <- model.matrix(Classe ~ . - 1, data = validacao)
  previsoes_lasso_val <- predict(lasso_model, newx = x_validacao, type = "response")
  
  x_teste <- model.matrix(Classe ~ . - 1, data = teste)
  previsoes_lasso_teste <- predict(lasso_model, newx = x_teste, type = "response")
  
  ## Tuning de hiperparâmetros para Random Forest
  cat("Treinando modelo: Random Forest\n")
  tic()
  tune_grid_rf <- expand.grid(mtry = c(2, 4, 6))
  rf_model <- train(Classe ~ ., data = treino_balanceado, method = "rf", tuneGrid = tune_grid_rf, trControl = trainControl(method = "cv", number = 5))
  toc()
  previsoes_rf_val <- predict(rf_model, newdata = validacao, type = "prob")[, 2]
  previsoes_rf_teste <- predict(rf_model, newdata = teste, type = "prob")[, 2]
  
  ## Tuning de hiperparâmetros para XGBoost
  cat("Treinando modelo: XGBoost\n")
  tic()
  # tune_grid_xgb <- expand.grid(nrounds = c(50, 100, 150), max_depth = c(3, 6, 9), eta = c(0.01, 0.1, 0.3))
  # xgb_model <- train(
  #   Classe ~ ., data = treino_balanceado, method = "xgbTree",
  #   tuneGrid = tune_grid_xgb, trControl = trainControl(method = "cv", number = 5)
  # )
  # toc()
  # previsoes_xgb_val <- predict(xgb_model, newdata = validacao, type = "prob")[, 2]
  # previsoes_xgb_teste <- predict(xgb_model, newdata = teste, type = "prob")[, 2]
  # 
  # ## Avaliação dos modelos no conjunto de validação e teste
  # for (modelo in list("LASSO" = list(previsoes_val = previsoes_lasso_val, previsoes_teste = previsoes_lasso_teste),
  #                     "Random Forest" = list(previsoes_val = previsoes_rf_val, previsoes_teste = previsoes_rf_teste),
  #                     "XGBoost" = list(previsoes_val = previsoes_xgb_val, previsoes_teste = previsoes_xgb_teste))) {
  #   nome_modelo <- names(modelo)
  #   previsoes_val <- modelo[[1]]$previsoes_val
  #   previsoes_teste <- modelo[[1]]$previsoes_teste
  ## Tuning de hiperparâmetros para XGBoost

  #tune_grid_xgb <- expand.grid(nrounds = c(50, 100, 150), max_depth = c(3, 6, 9), eta = c(0.01, 0.1, 0.3))
  tune_grid_xgb <- expand.grid(
    nrounds = c(50, 100, 150),
    max_depth = c(3, 6, 9),
    eta = c(0.01, 0.1, 0.3),
    gamma = 0,
    colsample_bytree = 1,
    min_child_weight = 1,
    subsample = 1
  )
  
  # xgb_model <- train(
  #   Classe ~ ., data = treino_balanceado, method = "xgbTree",
  #   tuneGrid = tune_grid_xgb, trControl = trainControl(method = "cv", number = 5)
  # )
  xgb_model <- train(
    Classe ~ ., data = treino_balanceado, method = "xgbTree",
    tuneGrid = tune_grid_xgb, trControl = trainControl(method = "cv", number = 5)
  )
  toc()
  previsoes_xgb_val <- predict(xgb_model, newdata = validacao, type = "prob")[, 2]
  previsoes_xgb_teste <- predict(xgb_model, newdata = teste, type = "prob")[, 2]
  
  ## Avaliação dos modelos no conjunto de validação e teste
  # for (modelo in list("LASSO" = list(previsoes_val = previsoes_lasso_val, previsoes_teste = previsoes_lasso_teste),
  #                     "Random Forest" = list(previsoes_val = previsoes_rf_val, previsoes_teste = previsoes_rf_teste),
  #                     "XGBoost" = list(previsoes_val = previsoes_xgb_val, previsoes_teste = previsoes_xgb_teste))) {
  #   nome_modelo <- names(modelo)
  #   previsoes_val <- modelo[[1]]$previsoes_val
  #   previsoes_teste <- modelo[[1]]$previsoes_teste
  modelos <- list(
    "LASSO" = list(previsoes_val = previsoes_lasso_val, previsoes_teste = previsoes_lasso_teste),
    "Random Forest" = list(previsoes_val = previsoes_rf_val, previsoes_teste = previsoes_rf_teste),
    "XGBoost" = list(previsoes_val = previsoes_xgb_val, previsoes_teste = previsoes_xgb_teste)
  )
  
  for (nome_modelo in names(modelos)) {
    previsoes_val <- modelos[[nome_modelo]]$previsoes_val
    previsoes_teste <- modelos[[nome_modelo]]$previsoes_teste
    
    matriz_confusao_val <- confusionMatrix(as.factor(ifelse(previsoes_val > 0.5, "A", "B")), validacao$Classe, positive = "A")
    # auc_val <- roc(validacao$Classe, previsoes_val)$auc
    if (length(unique(validacao$Classe)) == 2) {
      auc_val <- roc(validacao$Classe, previsoes_val)$auc
    } else {
      auc_val <- NA
      cat("Aviso: Não há ambas as classes no conjunto de validação. AUC não calculado.\n")
    }
    
    
    matriz_confusao_teste <- confusionMatrix(as.factor(ifelse(previsoes_teste > 0.5, "A", "B")), teste$Classe, positive = "A")
    # auc_teste <- roc(teste$Classe, previsoes_teste)$auc
    if (length(unique(teste$Classe)) == 2) {
      auc_teste <- roc(teste$Classe, previsoes_teste)$auc
    } else {
      auc_teste <- NA
      cat("Aviso: Não há ambas as classes no conjunto de teste. AUC não calculado.\n")
    }
    
    
    resultados[[paste(cenario, nome_modelo, "Validação", sep = " - ")]] <- list(
      Matriz_Confusao = matriz_confusao_val,
      AUC = auc_val,
      Métricas = matriz_confusao_val$byClass
    )
    
    resultados[[paste(cenario, nome_modelo, "Teste", sep = " - ")]] <- list(
      Matriz_Confusao = matriz_confusao_teste,
      AUC = auc_teste,
      Métricas = matriz_confusao_teste$byClass
    )
  }
}

## Exibir resultados
for (resultado in names(resultados)) {
  cat("\n---", resultado, "---\n")
  print(resultados[[resultado]]$Matriz_Confusao)
  cat("AUC:", resultados[[resultado]]$AUC, "\n")
  print(resultados[[resultado]]$Métricas)
}

## Comparação gráfica das performances
library(ggplot2)
métricas <- data.frame()

for (resultado in names(resultados)) {
  métricas <- rbind(métricas, data.frame(
    Cenário = resultado,
    AUC = resultados[[resultado]]$AUC,
    Sensibilidade = resultados[[resultado]]$Métricas["Sensitivity"],
    Especificidade = resultados[[resultado]]$Métricas["Specificity"]
  ))
}

## Gráfico de comparação de AUC
ggplot(métricas, aes(x = reorder(Cenário, AUC), y = AUC, fill = Cenário)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  labs(title = "Comparação de AUC entre Modelos", x = "Cenário e Modelo", y = "AUC") +
  theme_minimal()

## Gráfico de comparação de Sensibilidade e Especificidade
ggplot(métricas, aes(x = reorder(Cenário, Sensibilidade), y = Sensibilidade, fill = Cenário)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  labs(title = "Comparação de Sensibilidade entre Modelos", x = "Cenário e Modelo", y = "Sensibilidade") +
  theme_minimal()

ggplot(métricas, aes(x = reorder(Cenário, Especificidade), y = Especificidade, fill = Cenário)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  labs(title = "Comparação de Especificidade entre Modelos", x = "Cenário e Modelo", y = "Especificidade") +
  theme_minimal()
